package StringExamples;

public class StringMethods2 {

	public static void main(String[] args) {
		
		String str="HelloWorld";
		str=str.substring(3, 9);
		System.out.println("The substring created new is "+str);
		
		
		
		String s1="India is my country";
		int y=s1.length();
		System.out.println("Length of string is "+y);
		
	boolean flag=	s1.contains("myself");
	
	System.out.println("Does the string contains my "+flag);
	;
	String s2="India";
	String s3="INdia";
	
	//boolean flag2=s2.equals(s3);
	
	boolean flag2=s2.equalsIgnoreCase(s3);
	
	System.out.println("Are two string equals "+flag2);
		
		
		
		
	}

}

///SAURABH
