package StringExamples;

public class StringSplitMethod {

	public static void main(String[] args) {
		
		String str="India , is my country";
		
	String []a=	str.split(" ");
	
	System.out.println(a[2]);
	
	String str1="Hello&WorldMyIndia";
	
	String []b=str1.split("My");
	
	System.out.println(b[1]);
	
	
	
	
		

	}

}
