package StringExamples;

public class StringReplaceMethodEx {

	public static void main(String[] args) {
		
		String str="   Hello   World   ";
		
		str=str.trim();
		
		System.out.println("Original String is  " +str);
		
		
	str=	str.replace('H', 'T');
		
		System.out.println(str);
		
		
		//str=str.replaceAll('H', 'T');
		
		String str2="Hello How are you";
		
	str2=	str2.replaceAll(" ", "");
	
	System.out.println(str2);
	
	
	/// ^[a-zA-Z0-9],'d'

	}

}
