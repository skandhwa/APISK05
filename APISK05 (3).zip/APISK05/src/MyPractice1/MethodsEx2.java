package MyPractice1;


class M3
{
	int subtract()
	{
		int x=10-3;
		System.out.println(x);
		return x;
		
		
	}
	
	void test()
	{
		System.out.println("Hello");
	}
}


public class MethodsEx2 {

	public static void main(String[] args) {
		
		M3 oj=new M3();
		oj.test();
		oj.subtract();
		
		

	}

}
