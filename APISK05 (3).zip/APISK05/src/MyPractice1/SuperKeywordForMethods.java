package MyPractice1;


	
	class A8
	{
		void display()
		{
			System.out.println("Hello");
		}
	}
	
	class A9 extends A8
	{
		void test()
		{
			System.out.println("Hi");
		}
		void display()
		{
			System.out.println("I am new");
		}
		
		void message()
		{
			test();
			display();
			super.display();
		}
		
		
	}
	
	public class SuperKeywordForMethods {

	public static void main(String[] args) {
		
		A9 obj=new A9();
		obj.message();
		

	}

}
