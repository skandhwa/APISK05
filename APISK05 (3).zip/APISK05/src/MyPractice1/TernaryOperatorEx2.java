package MyPractice1;

public class TernaryOperatorEx2 {

	public static void main(String[] args) {
		
		int a=10;
		int b=40;
		int c=55;
		
		int max= a>b ?(a>c?a:c) :(b>c?b:c);
		
		System.out.println(max);
		
		
		int d=5;
		
		d*=8;// d=d+10=15
		
		System.out.println(d);
		
		
		

	}

}
