package MyPractice1;

public class MethodCascadingEx {
	
	void display()
	{
		System.out.println("hello");
	}
	
	
	void test()
	{
		System.out.println("Hi");
	}
	
	void message()
	{
		display();
		test();
	}
	
	

	public static void main(String[] args) {
		
		
		MethodCascadingEx obj=new MethodCascadingEx();
		obj.message();
		
		

	}

}
