package MyPractice1;

class Bank
{
	int getROI(int x,int y)
	{
		return x+y;
	}
}

class Axis extends Bank
{
	int getROI(int x,int y)
	{
		return x+y;
	}
}

class SBI extends Bank
{
	int getROI(int x,int y)
	{
		return x+y;
	}
}


public class MethodOverridingEx {

	public static void main(String[] args) {
		
		Axis obj=new Axis();
	System.out.println(obj.getROI(3, 2));	
	
	SBI obj1=new SBI();
	System.out.println(obj1.getROI(4, 2));	
		

	}

}
