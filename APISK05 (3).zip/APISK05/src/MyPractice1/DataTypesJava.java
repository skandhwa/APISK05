package MyPractice1;

public class DataTypesJava {

	public static void main(String[] args) {
		
	   boolean flag=true;
	   
	   System.out.println(flag);
	   
	   byte x=123;
	   
	   System.out.println(x);
	   
	   
	   short v=-32768;
	   
	   //int j=123213213213123;
		

	}

}
