package MyPractice1;

interface T8
{
	void display();
	void show();
	void test();
	
}


class T5 implements T8
{
	public void display()
	{
		System.out.println("Hi");
	}
	
	public void show()
	{
		System.out.println("Hello");
	}
	
	public void test()
	{
		System.out.println("Welcome");
	}
	
}


public class InterfaceEx1 {

	public static void main(String[] args) {
		
		T5 obj=new T5();
		obj.show();
        obj.test();
        obj.display();
        
        
        T8 ref=new T5();
        ref.show();
        ref.test();
        ref.display();
        
		

	}

}
