package MyPractice1;

public class MethodsExample1 {

	public static void main(String[] args) {
		
		
		

	}

}
