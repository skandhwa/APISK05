package MyPractice1;

class C2
{
	int id;
	String name;
	int val;
	
	C2(int id,String name,int val)
	{
		this.id=id;
		this.name=name;
		this.val=val;
	}
	
	void display()
	{
		System.out.println(id+"  "+name+"  "+val);
	}
	
}

public class IssueWithSameLocalAndInstanceVariable {

	public static void main(String[] args) {
		
		C2 obj=new C2(23,"Saurabh",78);
		obj.display();
		

	}

}
