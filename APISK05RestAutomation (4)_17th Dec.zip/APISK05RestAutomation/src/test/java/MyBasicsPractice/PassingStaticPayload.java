package MyBasicsPractice;

import static io.restassured.RestAssured.given;
import static org.hamcrest.Matchers.equalTo;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;

import org.testng.Assert;

import PayloadData.Payload;
import io.restassured.RestAssured;
import io.restassured.path.json.JsonPath;

public class PassingStaticPayload {

	public static void main(String[] args) throws IOException {
		

		RestAssured.baseURI="https://reqres.in";
		String Expected_Date="2024-12-11";
		
	String Response=	given().log().all().headers("Content-Type","application/json")
			.headers("","")
			.body( new String(Files.readAllBytes(Paths.get("E:\\APISK03_TestData24thJuly.txt"))
					
					)).
		when().post("api/users")
		.then().log().all().assertThat().statusCode(201)
		.
		
		extract().response().asString();
		
	
	System.out.println(Response);
	
	JsonPath js=new JsonPath(Response);
	String Actual_Date=js.getString("createdAt");
	
//String[]a=	Actual_Date.split("T");
//
//String Actual_Calendar_Day=a[0];
//
//System.out.println(a[0]);
//
//Assert.assertEquals(Actual_Calendar_Day, Expected_Date);
//
//System.out.println("Test Case passed");
		

	}

}
