package MyBasicsPractice;

import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import PayloadData.Payload;
import io.restassured.RestAssured;
import static io.restassured.RestAssured.*;

public class UsingDataProviderToPassTest {

	@DataProvider(name="BooksData")

	public Object [][] getBooksData()
	{

	return new Object [][]

	{
		{"acbcgh",3456},
		{"xnbcgh",9456},
		{"ygbcgh",8456},
		{"kgbcgh",8456},
		{"egbcgh",8456},
		{"tgbcgh",8456},
		{"ugbcgh",8456}
		
	};
	



	}
	
	
	
	@Test(dataProvider="BooksData")
	public void addBook(String ISBN,int aisle)
	{
		RestAssured.baseURI="http://216.10.245.166";
		
	String Response=	given().log().all().headers("Content-Type","application/json")
		.body(Payload.AddBooks(ISBN, aisle))
		.when().post("Library/Addbook.php").then().assertThat()
		.statusCode(200).extract().response().asString();
	
	System.out.println(Response);
		
	}
	
	
	
	

	
}
