package MapInterfaceEx;

import java.util.LinkedHashMap;
import java.util.Map;

public class MapEx5 {

	public static void main(String[] args) {
		
		
		Map<Object,Object> mp=new LinkedHashMap<Object,Object>();
		mp.put(12, "Saurabh");
		
		mp.put(false, 32);
		mp.put(3212312321321321321L, 88344.60f);
		mp.put(42, "Mahesh");
		
		

	}

}
