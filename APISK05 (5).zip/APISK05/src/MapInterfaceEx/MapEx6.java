package MapInterfaceEx;

import java.util.Map.Entry;
import java.util.TreeMap;

public class MapEx6 {

	public static void main(String[] args) {
		
		TreeMap<Integer,String> mp=new TreeMap<Integer,String>();
		mp.put(32,"Harsh");
		mp.put(22, "Gaurabh");
		mp.put(92, "Harish");
		mp.put(82, "Mahesh");
		
		System.out.println(mp);
		
//	Entry<Integer, String> val=	mp.ceilingEntry(32);
//	
//	System.out.println(val);
	
	int val1=mp.ceilingKey(85);
	
	System.out.println(val1);
	
mp.descendingMap();

System.out.println(mp.descendingMap());
		
		
		
		

	}

}
