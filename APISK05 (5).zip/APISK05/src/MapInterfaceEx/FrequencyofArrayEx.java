package MapInterfaceEx;

import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;

public class FrequencyofArrayEx {

	public static void main(String[] args) {
		
		int []a= {1,4,5,6,1,1,4,4,7,6,1,3,5,3,3,3,3,3};
		
		Map<Integer,Integer> mp=new LinkedHashMap<Integer,Integer>();
		
		for(int i=0;i<a.length;i++)//i=0,0<13//i=1
		{
			if(mp.containsKey(a[i]))//
			{
				mp.put(a[i] , ( mp.get(a[i])+1));
				
				////mp.put(1, 1+1)
			}
			
			else
			{
				mp.put(a[i],1);
			}
		}
		
		for(Map.Entry x:mp.entrySet())
		{
			System.out.print(x.getKey()+"  ");
			System.out.println(x.getValue());
		}
		
		
		int maxFrequency=0;
		int maxOccuringValue=0;
		
		
		for(Map.Entry<Integer, Integer> entry:mp.entrySet())
		{
			if(entry.getValue()>maxFrequency)
			{
				maxFrequency=entry.getValue();
				maxOccuringValue=entry.getKey();
			}
		}
		
		System.out.println("Maximum Occuring Integer is  " +maxOccuringValue
				+"  with a value of   "+maxFrequency);
		
		
		
		int minFrequency=1000;
		int minOccuringValue=1000;
		
		
		for(Map.Entry<Integer, Integer> entry:mp.entrySet())
		{
			if(entry.getValue()<minFrequency)
			{
				minFrequency=entry.getValue();
				minOccuringValue=entry.getKey();
			}
		}
		
		System.out.println("Minimum Occuring Integer is  " +minOccuringValue
				+"  with a value of   "+minFrequency);
		
		
		

	}

}
