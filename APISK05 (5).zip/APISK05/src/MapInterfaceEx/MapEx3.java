package MapInterfaceEx;

import java.util.HashMap;
import java.util.Map;

public class MapEx3 {

	public static void main(String[] args) {
		
		Map<Integer,String> mp=new HashMap<Integer,String>();
		mp.put(2,"Saurabh");
		mp.put(1,"Saurabh");
		mp.put(3,"Gaurabh");
		mp.put(6, "Harsh");
		
	String Value=	mp.get(2);
	
	System.out.println(Value);
		
	boolean flag=        mp.containsKey(6);
	
	System.out.println(flag);
	
	boolean flag1=mp.containsValue("Harsh");
	
	System.out.println(flag1);
	
	mp.remove(2);
	
	System.out.println(mp);
	
	
	

	}

}
