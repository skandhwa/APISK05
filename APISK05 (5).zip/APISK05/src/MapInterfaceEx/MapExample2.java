package MapInterfaceEx;

import java.util.HashMap;
import java.util.Map;

public class MapExample2 {

	public static void main(String[] args) {
		
		
		Map<Integer,Integer>mp=new HashMap<Integer,Integer>();
		mp.put(12,20);
		mp.put(10,30);
		mp.put(2,40);
		mp.put(22,60);
		mp.put(22,600);
		
		Map<Integer,Integer>mp2=new HashMap<Integer,Integer>();
		mp.put(412,20);
		mp.put(110,30);
		mp.put(32,40);
		mp.put(42,60);
		mp.put(92,600);
		
		mp.clear();
		
		

	}

}
