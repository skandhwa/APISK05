package MapInterfaceEx;

import java.util.HashMap;
import java.util.Map;

public class MapEx1 {

	public static void main(String[] args) {
		
		Map<Integer,Integer>mp=new HashMap<Integer,Integer>();
		mp.put(12,20);
		mp.put(10,30);
		mp.put(2,40);
		mp.put(22,60);
		mp.put(22,600);
		
		System.out.println(mp);
		
		for(Map.Entry m: mp.entrySet())
		{
			System.out.print(m.getKey() +"  ");
			System.out.println(m.getValue());
		}
		
		
		
		
	}

}
