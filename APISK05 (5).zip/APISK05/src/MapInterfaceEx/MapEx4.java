package MapInterfaceEx;

import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;

public class MapEx4 {

	public static void main(String[] args) {
		
		Map<Integer,String> mp=new LinkedHashMap<Integer,String>();
		mp.put(12, "Saurabh");
		
		mp.put(22, "Gaurabh");
		mp.put(32, "Harish");
		mp.put(42, "Mahesh");
		
		for(Map.Entry x:mp.entrySet())
		{
			System.out.println(x.getKey());
			System.out.println(x.getValue());
		}
		
		
		
		

	}

}
