package ExceptionHandlingExamples;

class T10
{
	void checkAge(int age)
	{
		if(age<18)
		{
			throw new ArithmeticException ("Invalid age");
		}
		
		else
		{
			System.out.println("You are elligible to vote");
			System.out.println("Vote increased by +1");
		}
	}
}
public class HandlingException4 {

	public static void main(String[] args) {
		
		T10 obj=new T10();
		obj.checkAge(25);
		
		
		
		

	}

}
