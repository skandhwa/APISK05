package ExceptionHandlingExamples;

import java.io.IOException;

public class HandlingCheckedExceptionThrow {
	
	public static void checkFileExist(int code) throws IOException 
	{
		int value=739331;
		if(value==code)
		{
			System.out.println("You have the access to file");
		}
		else
		{
			throw new IOException("No file present");
		}
	}
	
	
	
	
	

	public static void main(String[] args) throws IOException {
		
		HandlingCheckedExceptionThrow.checkFileExist(876543);
		
		int a=20;
		int b=10;
		
		int c=a+b;
		
		System.out.println("sum is "+c);
		
		

	}

}
