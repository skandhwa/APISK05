package ExceptionHandlingExamples;

public class HandlingException3 {

	public static void main(String[] args) {
		try
		{
		String str=null;
		int x=str.length();
		System.out.println("Length of string is "+x);
		
		int y=9/0;
		System.out.println(y);
		
        int []n= {3,5,7,8,11};
		
		System.out.println(n[5]);
		}
		
		catch(ArithmeticException e)
		{
			System.out.println("caught with "+e);
		}
		
		catch(ArrayIndexOutOfBoundsException e)
		{
			System.out.println("caught with "+e);
		}
		
		catch(NullPointerException e)
		{
			System.out.println("caught with "+e);
		}
		
		int a=20,b=30;
		int c=a+b;
		System.out.println("Sum is "+c);

		

	}

}
