package Collections;

import java.util.ArrayList;
import java.util.Collections;

public class ArrayListMethods4 {

	public static void main(String[] args) {
		
		ArrayList<String> li=new ArrayList<String>();
		li.add("Mango");
		li.add("Orange");
		li.add("banana");
		
		Collections.sort(li);
		
		Collections.reverse(li);
		
		System.out.println("Reverse list are "+li);
		
		
		ArrayList<String> li2=new ArrayList<String>();
		li2.add("Kiwi");
		li2.add("Guava");
		li2.add("banana");
		
		
		li.removeAll(li2);
		System.out.println("After removing elements are");
		
		for(String x:li)
		{
			System.out.println(x);
		}
		
	}

}
