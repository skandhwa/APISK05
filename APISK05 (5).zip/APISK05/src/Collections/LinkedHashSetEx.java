package Collections;

import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.Set;

public class LinkedHashSetEx {

	public static void main(String[] args) {
		
		
Set<Integer> s1=new LinkedHashSet<Integer>();
		
		s1.add(23);
		s1.add(67);
		s1.add(99);
		s1.add(103);
		s1.add(null);
		
		s1.add(null);
		
		
		System.out.println(s1);

	}

}
