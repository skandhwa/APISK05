package Collections;

import java.util.Iterator;
import java.util.TreeSet;

public class TreeSetEx1 {

	public static void main(String[] args) {
		
		TreeSet <Integer> t1=new TreeSet<Integer>();
		 t1.add(9);
		 t1.add(109); 
		 t1.add(199);
		 t1.add(55);
		 t1.add(68);
		 
		 
		 for(Integer x:t1)
		 {
			 System.out.println(x);
		 }
		 
		 
		 System.out.println("Elements of set in descending order is ");
		 
		 Iterator itr=t1.descendingIterator();
		 while(itr.hasNext()) 
		 {
			 System.out.println(itr.next());
		 }
		 
		 System.out.println("Reverse set is " +t1.descendingSet());
		
		 
		 
		 
		
		
		

	}

}
