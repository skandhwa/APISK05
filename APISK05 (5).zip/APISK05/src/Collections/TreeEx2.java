package Collections;

import java.util.TreeSet;

public class TreeEx2 {

	public static void main(String[] args) {
		
		TreeSet<String> s1=new TreeSet<String>();
		s1.add("A");
		s1.add("B");
		s1.add("C");
		s1.add("D");
		s1.add("E");
		
		System.out.println("Reverse set is "+s1.descendingSet());
		
		System.out.println("Head Set is "+s1.headSet("C",false));
		
		System.out.println("Tail Set is "+s1.tailSet("C",false));
		
		System.out.println("Sub Set is "+s1.subSet("A",true, "E", true));
		

	}

}
