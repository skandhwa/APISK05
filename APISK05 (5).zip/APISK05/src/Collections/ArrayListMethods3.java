package Collections;

import java.util.ArrayList;

public class ArrayListMethods3 {

	public static void main(String[] args) {
		
		ArrayList<String> li=new ArrayList<String>();
		li.add("Mango");
		li.add("Orange");
		li.add("banana");
		
		ArrayList<String> li2=new ArrayList<String>();
		li2.add("Kiwi");
		li2.add("Guava");
		li2.add("banana");
		
	boolean flag=	li.contains("Mango");
	
	System.out.println("Does the list contains Mango "+flag);
	
	li.retainAll(li2);
	
	
	
	for(Object x:li)
	{
		System.out.println(x);
	}
	
	li.removeAll(li2);
	
	System.out.println("After removing elements are");
	
	for(Object y:li)
	{
		System.out.println(y);
	}
	
	
	
	
	
		

	}

}
