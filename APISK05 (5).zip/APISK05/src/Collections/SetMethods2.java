package Collections;

import java.util.HashSet;
import java.util.Set;

public class SetMethods2 {

	public static void main(String[] args) {
		
		
Set<Integer> s1=new HashSet<Integer>();
		
		s1.add(23);
		s1.add(67);
		s1.add(99);
		s1.add(103);
		
		
Set<Integer> s2=new HashSet<Integer>();
		
		s2.add(23);
		s2.add(67);
		s2.add(99);
		s2.add(193);
		s2.add(89);
	
		
boolean flag=		s1.containsAll(s2);

System.out.println(flag);
		
		s1.clear();
		
		System.out.println("Elements of set are "+s1);

	}

}
