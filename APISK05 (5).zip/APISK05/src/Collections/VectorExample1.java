package Collections;

import java.util.Vector;

public class VectorExample1 {

	public static void main(String[] args) {
		
		Vector<Object> v1=new Vector<Object>();
		
		v1.add("Mango");
		v1.add(34);
		v1.add('A');
		
		for(Object x:v1)
		{
			System.out.println(x);
		}
		
		

	}

}
