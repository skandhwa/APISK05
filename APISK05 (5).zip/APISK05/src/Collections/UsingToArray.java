package Collections;

import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;

public class UsingToArray {

	public static void main(String[] args) {
		 Set<Integer> s1=new HashSet<Integer>();
			
			s1.add(23);
			s1.add(67);
			s1.add(99);
			s1.add(103);
			
	boolean flag=		s1.contains(67);
	
	System.out.println("Does the set contains 67 "+flag);
	
	
	
	
			
	Object[]obj=		s1.toArray();
	
	System.out.println(Arrays.toString(obj));

	}

}
