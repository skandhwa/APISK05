package Collections;

import java.util.LinkedList;
import java.util.List;

public class LinkedListEx {

	public static void main(String[] args) {
		
		LinkedList<Object> li=new LinkedList<Object>();
		
		li.add("Guava");
		li.add(34);
		li.add(false);
		li.add(56.75f);
		
LinkedList<Object> li2=new LinkedList<Object>();
		
		li2.add("Guava");
		li2.add(34);
		li2.add(false);
		li2.add(56.75f);
		
	boolean flag=	li.equals(li2);
	
	System.out.println("Are both list same "+flag);
		
		for(Object x:li)
		{
			System.out.println(x);
		}
		
		li.add(3,"Saurabh");
		
		System.out.println("After adding Saurabh");
		for(Object y:li)
		{
			System.out.println(y);
		}
		
	li.clear();
	
	System.out.println("After clearing list");
	for(Object y:li)
	{
		System.out.println(y);
	}
		
	
		
		
		
		

	}

}
