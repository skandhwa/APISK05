package Collections;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Objects;

public class ArrayListToArrayEx {

	public static void main(String[] args) {
		
		
		ArrayList<String> li=new ArrayList<String>();
		li.add("Mango");
		li.add("Orange");
		li.add("banana");
		
		System.out.println(li);
		
		Object[] obj=li.toArray();
		
		
		String []a= {"Java" ,"Selenium","Python"};
		
		List al=Arrays.asList(a);
		

	}

}
