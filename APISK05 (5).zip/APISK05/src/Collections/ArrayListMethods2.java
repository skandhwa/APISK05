package Collections;

import java.util.ArrayList;
import java.util.List;

public class ArrayListMethods2 {

	public static void main(String[] args) {
		
		
		List<Object> li=new ArrayList<Object>();
		li.add(34);
		li.add("Apple");
		li.add(true);
		
		for(Object x:li)
		{
			System.out.println(x);
		}
		
		li.set(1, 'A');
		
		System.out.println("after adding character");
		
		for(Object x:li)
		{
			System.out.println(x);
		}
		
		System.out.println(li.get(2));
		
		

	}

}
