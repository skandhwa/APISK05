package Collections;

import java.util.HashSet;
import java.util.Set;

public class SetAddAllMethods {

	public static void main(String[] args) {
		
         Set<Integer> s1=new HashSet<Integer>();
		
		s1.add(23);
		s1.add(67);
		s1.add(99);
		s1.add(103);
		
	s1.add(183);
	s1.add(74);
	
	int x=s1.size();
	
	System.out.println("The total length of the set is "+x);
		
		
		   Set<Integer> s2=new HashSet<Integer>();
			
			s2.add(123);
			s2.add(167);
			s2.add(199);
			s2.add(183);
			s2.add(74);
			s2.add(67);
			
//			s1.addAll(s2);
//			
//			System.out.println(s1);
			
			
//			s1.removeAll(s2);
//			
//			System.out.println(s1);
			
			s1.retainAll(s2);
			
			System.out.println(s1);
			
		
		

	}

}
