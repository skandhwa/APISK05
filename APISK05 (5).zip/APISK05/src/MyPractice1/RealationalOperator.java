package MyPractice1;

public class RealationalOperator {

	public static void main(String[] args) {
		
		System.out.println(23==46/2);
		 //
		
		/// >, >=, < ,<= ,==, 

	}

}
