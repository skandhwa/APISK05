package MyPractice1;


class A
{
	int id;
	String name;
	int test;
	A(int i,String n)
	{
		id=i;
		name=n;
	}
	A(int i,String n,int t)
	{
		id=i;
		name=n;
		test=t;
		}
	void display()
	{
		System.out.println(id+" "+name+" "+test);
	}
	
	}
public class ParameterizedConstructor {

	public static void main(String[] args) {
		
		A obj=new A(12,"Saurabh");
		obj.display();
		
		A obj1=new A(12,"Saurabh",57);
		obj1.display();
		
		
		
		
		

	}

}
