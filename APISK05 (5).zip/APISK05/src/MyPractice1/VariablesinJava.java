package MyPractice1;




public class VariablesinJava {
	
	int x=10;
	
	void display()
	{
		int y=20;
		int z=x+y;
		
		
	}
	
	void test()
	{
		int p=y+30;
	}
	
	

	public static void main(String[] args) {
		

	}

}
