package MyPractice1;

public class OperatorsEx1 {

	public static void main(String[] args) {
		
		int a=5;//6
		int b=8;//8
		
		int c=  a++ + --b + b++ - b-- + ++a +a++;
		
		///  5 + 7 + 7- 8 + 7 +7
		
	//25 //26//28
		
		
		
		
		System.out.println(c);
		

	}

}
