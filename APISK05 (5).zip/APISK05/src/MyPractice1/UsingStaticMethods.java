package MyPractice1;

class M6
{
	static void display()
	{
		System.out.println("Hello");
	}
}



public class UsingStaticMethods {

	public static void main(String[] args) {
		
		M6.display();
		
		

	}

}
