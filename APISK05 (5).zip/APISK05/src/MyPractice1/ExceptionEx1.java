package MyPractice1;

public class ExceptionEx1 {

	public static void main(String[] args) {
		
		int x=9/0;
		System.out.println(x);
		
		
		

	}

}
