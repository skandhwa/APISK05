package MyPractice1;

class A7
{
	String colour="violet";
}

class A2 extends A7
{
	String colour="red";
	void test()
	{
		System.out.println(colour);
		System.out.println(super.colour);
	}
}

class A5 extends A2
{
	String colour="blue";
	void display()
	{
		System.out.println(colour);
		System.out.println(super.colour);
	}
}



public class SuperKeywordEx {

	public static void main(String[] args) {
		
		A5 obj=new A5();
		obj.display();
		

	}

}
