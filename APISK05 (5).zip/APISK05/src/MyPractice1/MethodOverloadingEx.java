package MyPractice1;

class Student3
{
	int id;
	String name;
	static String  company="Infosys";
	
	static void change()
	{
		company="Wipro";
	}

  Student3(int id,String name)
  {
	  this.id=id;
	  this.name=name;
  }
  
  void display()
  {
	  
	  System.out.println(id+" "+name+" "+company);
  }



}

public class MethodOverloadingEx {

	public static void main(String[] args) {
		
		Student3 obj=new Student3(23,"Saurabh");
		Student3 obj1=new Student3(13,"Gaurabh");
		Student3 obj2=new Student3(43,"Samar");
		Student3 obj3=new Student3(73,"Sakti");
		
		Student3.change();
		obj.display();
		obj1.display();
		obj2.display();
		obj3.display();
		
		
		

	}

}
