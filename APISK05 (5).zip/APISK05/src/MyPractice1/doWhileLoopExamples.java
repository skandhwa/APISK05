package MyPractice1;

public class doWhileLoopExamples {

	public static void main(String[] args) {
		
		int i=10;
		
		
		do
		{
			System.out.println(i);//10//11//12
			i++;//10++//11++
		}
		while(i<=5);//11<=15//12<=15

	}

}
