package StringExamples;

public class StringBufferExample {

	public static void main(String[] args) {
		
		StringBuffer sb=new StringBuffer("India");
		
		sb.append("Nation");
		
		
		System.out.println(sb);
		
		StringBuffer sb1=new StringBuffer("Java");
		
		sb1.replace(1, 3, "Hello");
		
		System.out.println(sb1);
		
		
		
		

	}

}
