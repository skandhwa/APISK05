package StringExamples;

public class StringDeclaration1 {

	public static void main(String[] args) {
		
		String str="Hello";
	String	str1=	str.concat("world");
		
		System.out.println(str1);
		
		
		///Using new Keyword
		
		String s1=new String("Hello");
		
		s1.concat("World");
		
		System.out.println(s1);
		
		
		
		

	}

}
