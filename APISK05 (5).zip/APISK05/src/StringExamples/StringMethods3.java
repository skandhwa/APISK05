package StringExamples;

public class StringMethods3 {

	public static void main(String[] args) {
		
		String str="";
		
	boolean flag2=	str.isEmpty();
	
	System.out.println("Is the string empty "+flag2);
	
	String s1="Hello";
	
	s1=s1.concat("World");
	
	System.out.println(s1);
	
		

	}

}
