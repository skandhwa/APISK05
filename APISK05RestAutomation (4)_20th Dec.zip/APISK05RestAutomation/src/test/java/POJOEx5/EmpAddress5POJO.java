package POJOEx5;

public class EmpAddress5POJO {
	
	private HouseDetails5POJO housedetails;
	private int zip;
	private String state;
	private String city;
	
	
	public HouseDetails5POJO getHousedetails() {
		return housedetails;
	}
	public void setHousedetails(HouseDetails5POJO housedetails) {
		this.housedetails = housedetails;
	}
	public int getZip() {
		return zip;
	}
	public void setZip(int zip) {
		this.zip = zip;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	
	

}
