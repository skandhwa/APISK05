package POJOEx5;

import java.util.List;

public class HouseDetails5POJO {
	
	private int flatNo;
	private String Street;
	private String AppartmentName;
	private List<String>Landmark;
	
	
	public int getFlatNo() {
		return flatNo;
	}
	public void setFlatNo(int flatNo) {
		this.flatNo = flatNo;
	}
	public String getStreet() {
		return Street;
	}
	public void setStreet(String street) {
		Street = street;
	}
	public String getAppartmentName() {
		return AppartmentName;
	}
	public void setAppartmentName(String appartmentName) {
		AppartmentName = appartmentName;
	}
	public List<String> getLandmark() {
		return Landmark;
	}
	public void setLandmark(List<String> landmark) {
		Landmark = landmark;
	}
	
	
	
	

}
