package POJOEx5;

import static io.restassured.RestAssured.given;

import java.util.ArrayList;
import java.util.List;


import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import io.restassured.RestAssured;
import io.restassured.path.json.JsonPath;

public class CreateEmployee5 {

	public static void main(String[] args) throws JsonProcessingException {
		
		HouseDetails5POJO hdetails=new HouseDetails5POJO();
		hdetails.setAppartmentName("GCK Appartment");
		hdetails.setFlatNo(23);
		hdetails.setStreet("PR Street");
	
		List<String> landmark=new ArrayList<String>();
		landmark.add("ABC sweets");
		landmark.add("DP Hotel");
		landmark.add("JK Mall");
		
		hdetails.setLandmark(landmark);
		
		
		EmpAddress5POJO empAddress=new EmpAddress5POJO();
		empAddress.setHousedetails(hdetails);
		empAddress.setCity("Kolkata");
		empAddress.setState("WB");
		empAddress.setZip(700044);
		
		Employee5POJO emp=new Employee5POJO();
		emp.setAge(32);
		emp.setEmpAddress(empAddress);
		emp.setMarried(false);
		
		emp.setName("harry");
		
		List<String> banks=new ArrayList<String>();
		banks.add("Axis");
		banks.add("SBI");
		banks.add("ICICI");
		
		emp.setBanks(banks);
		
		ObjectMapper obj=new ObjectMapper();
String empJSON=		obj.writerWithDefaultPrettyPrinter().writeValueAsString(emp);		
	

RestAssured.baseURI="https://reqres.in";

String Response=		given().log().all().body(empJSON)
.headers("Content-Type","application/json" )
.when().post("api/users")
.then().log().all().
extract().response().asString();

System.out.println(Response);

JsonPath js=new JsonPath(Response);


String library=js.getString("empAddress.housedetails.landmark[0]");
System.out.println("The nearest landmark is   "+library);

		
		
		
		

	}

}
