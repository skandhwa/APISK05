package MISC;

import java.io.File;

import io.restassured.RestAssured;
import static io.restassured.RestAssured.*;

public class FileAsInput {

	public static void main(String[] args) {
		
		File f=new File("D:\\Payload6.txt");
		File f1=new File("C:\\Users\\saura\\OneDrive\\Documents\\DocumentToUpload.txt.txt");
		
		RestAssured.baseURI="https://httpbin.org";
		
String Response	=	given().log().all().headers("Content-Type","multipart/form-data")
		.multiPart("file",f)
		.multiPart("file",f1)
		
		.when().post("post")
		.then().log().all().extract().response()
		.asString();

System.out.println(Response);
		
		

	}

}
