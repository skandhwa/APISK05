package MISC;

import static io.restassured.RestAssured.given;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import io.restassured.RestAssured;

public class UsingListToPassPayload {

	public static void main(String[] args) {
		
		Map<String,Object> mp=new LinkedHashMap<String,Object>();
		mp.put("name","gourav");
		
		mp.put("salary",560000f);
		mp.put("Is Married",true);
		
		
		Map<String,Object> mp1=new LinkedHashMap<String,Object>();
		mp1.put("name","sourav");
		
		mp1.put("salary",760000f);
		mp1.put("Is Married",false);
		
		Map<String,Object> mp2=new LinkedHashMap<String,Object>();
		mp2.put("name","kourav");
		
		mp2.put("salary",1160000f);
		mp2.put("Is Married",true);
		
		
		ArrayList<Map> li=new ArrayList<Map>();
		
		li.add(mp);
		li.add(mp1);
		li.add(mp2);
		
		
		RestAssured.baseURI="https://reqres.in";
		String Response=		given().log().all().relaxedHTTPSValidation().
				headers("Content-Type","application/json").
				body(li).
		when().post("api/users")
				.then().log().all()
				.assertThat().statusCode(201)
				.extract().response().asString();
		
		System.out.println(Response);
		

	}

}
