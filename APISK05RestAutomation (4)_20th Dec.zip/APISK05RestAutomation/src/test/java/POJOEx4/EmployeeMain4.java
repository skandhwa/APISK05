package POJOEx4;

import java.util.ArrayList;
import java.util.List;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

public class EmployeeMain4 {

	public static void main(String[] args) throws JsonProcessingException {
		
		EmployeeAddress4POJO empAddress=new EmployeeAddress4POJO();
		empAddress.setCity("Kolkata");
		empAddress.setState("WB");
		empAddress.setZip(700043);
		
		List<String> banks=new ArrayList<String>();
		banks.add("SBI");
		banks.add("HDFC");
		banks.add("ICICI");
		
		EmployeeCreatePOJO emp=new EmployeeCreatePOJO();
		
		emp.setAge(32);
		emp.setBank(banks);
		emp.setEmpAddress(empAddress);
		emp.setName("Rohit");
		emp.setSalary(960000f);
		emp.setIsMarried(false);
		
		ObjectMapper obj=new ObjectMapper();
	String empJson=	obj.writerWithDefaultPrettyPrinter().writeValueAsString(emp);
		

	}

}
