package Authentication;

import static io.restassured.RestAssured.given;

import io.restassured.RestAssured;

public class DigestAuthenticationEx {

	public static void main(String[] args) {
		
		
RestAssured.baseURI="https://httpbin.org";
		
		
		String Response=	given().log().all().auth().digest("saurabh1","saurabh1")
				
			.when().get("digest-auth/undefined/saurabh1/saurabh1")
			.then(). 
			assertThat().statusCode(200)
			.extract().response().asString();
		
		
		System.out.println(Response);


	}

}
