package Authentication;

import io.restassured.RestAssured;
import io.restassured.response.Response;

import static io.restassured.RestAssured.*;

import org.testng.Assert;

import PayloadData.Payload;

public class BearerTokenAuthentication {

	public static void main(String[] args) {
		
	String BearerToken="Bearer a682a89b74963538f47d3ec72b6af8f655ef7c20f8d1a7e3ad8582ffd8dfdf64";	
	RestAssured.baseURI="https://gorest.co.in"	;
	
Response response=	given().log().all().body(Payload.AddUserCredentials())
			.headers("Authorization",BearerToken)
			.headers("Content-Type","application/json")
			.when().post("/public/v2/users")
			.then().log().all().extract().response();

int statuscode=response.getStatusCode();

long ResponseTime=response.getTime();

System.out.println("Response time is  "+ResponseTime);

Assert.assertEquals(statuscode, 201);
System.out.println("TestCase Passed");





			
			
			

			
	

	}

}
