package Authentication;

import io.restassured.RestAssured;
import io.restassured.path.json.JsonPath;

import static io.restassured.RestAssured.*;

import org.testng.Assert;

public class APIKeyAuthentication {

	public static void main(String[] args) {
		
		RestAssured.baseURI="https://api.openweathermap.org";
		
String Response=		given().log().all().queryParam("q", "")
		.queryParam("appid", "4c834f2c753226cb4953a66effe44611")
		.when().get("data/2.5/weather")
		.then().log().all().assertThat().statusCode(401)
		.extract().response().asString();

System.out.println(Response);
		
//JsonPath js =new JsonPath(Response);	
//
//int humidity=js.getInt("main.humidity");
//
//Assert.assertEquals(68,humidity );
//System.out.println("Test Case passed");
		

	}

}
