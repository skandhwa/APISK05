package MyPractice1;

class A3
{
	void display()
	{
		System.out.println("Hello");
	}
}

class B1 extends A3
{
	void test()
	{
		System.out.println("Hi");
	}
	
	
}

class C1 extends B1
{
	void test1()
	{
		
	}
}


public class InheritanceEx {

	public static void main(String[] args) {
		
		B1 obj=new B1();
		obj.display();
		obj.test();
		

	}

}
