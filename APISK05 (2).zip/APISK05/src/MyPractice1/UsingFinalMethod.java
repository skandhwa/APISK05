package MyPractice1;

final class D2
{
	 void run()
	{
		System.out.println("Hello");
	}
}

class D3 extends D2

{
	void run()
	{
		System.out.println("Hi");
	}
}



public class UsingFinalMethod {

	public static void main(String[] args) {
		

	}

}
