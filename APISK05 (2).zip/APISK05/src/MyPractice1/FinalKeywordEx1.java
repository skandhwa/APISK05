package MyPractice1;

class Test
{
	  final int speed=100;
	
	public void run()
	{
		speed=100;
		System.out.println(speed);
	}
	
	
}

public class FinalKeywordEx1 {

	public static void main(String[] args) { 
		
		Test obj=new Test();
		obj.run();
		
		
		

	}

}
