package MyPractice1;

public class LogicalOperatorEx {

	public static void main(String[] args) {
		
		int a=12;
		int b=15;
		int c=19/2;
		
		if(a>b || b<c || a>c)/// 
		{
			System.out.println("true");
		}
		
		else
			System.out.println("false");
		

	}

}
