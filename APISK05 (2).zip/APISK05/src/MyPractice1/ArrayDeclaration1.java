package MyPractice1;

public class ArrayDeclaration1 {

	public static void main(String[] args) {
		
		int []a= {23,67,87,99,12,45};
		
		int []b=new int[5];
		
		b[0]=12;
		b[1]=134;
		b[2]=122;
		b[3]=324;
		b[4]=129;
		
		for(int i=0;i<b.length;i++)
		{
			System.out.println(b[i]);
		}
	
		

	}

}
