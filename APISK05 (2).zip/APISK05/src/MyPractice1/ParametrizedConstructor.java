package MyPractice1;


class M2
{
	int i;
	String n;
	
	M2(int id,String name)
	{
		i=id;
		n=name;
	}
	
	void display()
	{
		System.out.println(i);
		System.out.println(n);
	}
	
	
}

public class ParametrizedConstructor {
	
public static void main(String[] args) {
	
	M2 obj=new M2(1234,"Saurabh");
		
		
		

	}

}
