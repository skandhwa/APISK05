package StepDefinition;

import io.cucumber.java.After;
import io.cucumber.java.Before;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class stepDefinition {
	
	@Before
	public void test1()
	{
		System.out.println("This is before hooks");
	}
	
	@After 
	public void afterTest()
	{
		System.out.println("This is after hooks");
	}
	
	@Before("@test1")
	public void tagged1()
	{
		System.out.println("This is tagged before test 1hooks");
	}
	
	@After("@test1")
	public void tagged2()
	{
		System.out.println("This is tagged after test1 hooks");
	}
	
	@Before("@test2")
	public void tagged3()
	{
		System.out.println("This is tagged before test2 hooks");
	}
	
	@After("@test2")
	public void tagged4()
	{
		System.out.println("This is after test2 hooks");
	}
	
	
	@Given("user enters the URL in the browser")
	public void user_enters_the_url_in_the_browser() {
	    
	}

	@Given("user enters the username as {string}")
	public void user_enters_the_username_as(String string) {
		
	}
	
	   

	@Given("user enters the password as  {string}")
	public void user_enters_the_password_as(String string) {
	   
	}

	@When("user clicks on the login button of the application")
	public void user_clicks_on_the_login_button_of_the_application() {
	    
	}

	@Then("user is navigated to the homepage of the application")
	public void user_is_navigated_to_the_homepage_of_the_application() {
	    
	}
	
	
	@When("user selects the product")
	public void user_selects_the_product() {
	   
	}

	@When("user add items to cart")
	public void user_add_items_to_cart() {
	    
	}

	@When("user clicks on proceed to payment button")
	public void user_clicks_on_proceed_to_payment_button() {
	    
	}

	@Then("payment is processed")
	public void payment_is_processed() {
	    
	}



	
	

}
