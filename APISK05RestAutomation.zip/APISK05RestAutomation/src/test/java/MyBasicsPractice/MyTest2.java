package MyBasicsPractice;

import io.restassured.RestAssured;
import static io.restassured.RestAssured.given;
import static io.restassured.RestAssured.when;


public class MyTest2 {

	public static void main(String[] args) {
		
		RestAssured.baseURI="https://reqres.in";
		
	String Response=	given().log().all().queryParam("page", 2)
			.queryParam("", "")
			.queryParam("", "")
		.when().get("api/users")
		.then().log().all().assertThat().statusCode(200).extract().response().asString();
		
	
	System.out.println(Response);
		
		

	}

}
