package MyBasicsPractice;

import org.testng.annotations.Test;

import io.restassured.RestAssured;
import static io.restassured.RestAssured.*;


public class MyTest1 {
	
	@Test
	public void method1()
	{
		RestAssured.baseURI="https://reqres.in";
		
String Response=		given().log().all().headers("Connection","keep-alive").
when().get("api/users/2")
		.then().log().all().
		assertThat().statusCode(200).headers("Server","cloudflare")
		.extract().response().
		asString();
		
System.out.println(Response);

		
		
	}
	

}
