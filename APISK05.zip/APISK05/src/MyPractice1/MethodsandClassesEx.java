package MyPractice1;

class TestNew
{
	void display()
	{
		System.out.println("Hello");
	}
	
	void test()
	{
		System.out.println("Hi");
	}
	
	int sum()
	{
		return 5+8;
	}
	
}



public class MethodsandClassesEx {

	public static void main(String[] args) {
		
		TestNew obj=new TestNew();
		obj.display();
		obj.test();
		
	System.out.println(obj.sum());	
		

	}

}
