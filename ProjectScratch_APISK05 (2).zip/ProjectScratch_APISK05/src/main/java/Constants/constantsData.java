package Constants;

public class constantsData {
	
	public static final String propertyfilepath="src/main/java/Global.properties";
    public static final String testDataPath="C:\\Users\\saura\\OneDrive\\Documents\\TestData14thJan.xlsx";
}
