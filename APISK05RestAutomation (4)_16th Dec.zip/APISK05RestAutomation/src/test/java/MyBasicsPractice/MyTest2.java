package MyBasicsPractice;

import io.restassured.RestAssured;
import io.restassured.path.json.JsonPath;

import static io.restassured.RestAssured.given;
import static io.restassured.RestAssured.when;

import org.testng.Assert;


public class MyTest2 {

	public static void main(String[] args) {
		
		String Expected_Email="george.edwards@reqres.in";
		int Actual_Id=12;
		
		RestAssured.baseURI="https://reqres.in";
		
	String Response=	given().log().all().queryParam("page", 2)
			.queryParam("", "")
			.queryParam("", "")
		.when().get("api/users")
		.then().log().all().assertThat().statusCode(200).extract().response().asString();
		
	
	System.out.println(Response);
	
	JsonPath js=new JsonPath(Response);
	
	
String Actual_Email=	js.getString("data[4].email");

Assert.assertEquals(Actual_Email, Expected_Email);



int Expected_Id=js.getInt("data[5].id");

Assert.assertEquals(Actual_Id, Expected_Id);

System.out.println("Test Case Passed");

	
		
		

	}

}
