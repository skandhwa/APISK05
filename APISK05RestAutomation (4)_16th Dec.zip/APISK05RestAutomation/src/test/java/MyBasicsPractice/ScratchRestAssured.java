package MyBasicsPractice;

import io.restassured.RestAssured;
import static  io.restassured.RestAssured.*;

public class ScratchRestAssured {

	public static void main(String[] args) {
		
		
		
		
		

	}

}
