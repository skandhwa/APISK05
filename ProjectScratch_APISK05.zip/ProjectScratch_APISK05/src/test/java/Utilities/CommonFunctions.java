package Utilities;

public class CommonFunctions {

}
