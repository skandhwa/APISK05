package StepDefinition7;

import Utilities.FetchDatafromProperty;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import io.restassured.builder.RequestSpecBuilder;
import io.restassured.builder.ResponseSpecBuilder;
import io.restassured.http.ContentType;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import io.restassured.specification.ResponseSpecification;


import static io.restassured.RestAssured.*;

import org.testng.Assert;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;

import POJOMapper.CreateUser;

public class StepDefinition7 {
	
	RequestSpecification req;
	RequestSpecification res;
	ResponseSpecification respec;
	Response response;
	
	String URL=FetchDatafromProperty.readDataFromProperty().getProperty("URL1");
	
	
	

	@Given("user has requested to hit an application URL")
	public void user_has_requested_to_hit_an_application_url() {
		
		req=new RequestSpecBuilder().setBaseUri(URL).setContentType(ContentType.JSON)
				.build();
	    
	}

	@Given("user will pass the payload with all needed details")
	public void user_will_pass_the_payload_with_all_needed_details() throws JsonProcessingException {
		
		res=given().log().all().relaxedHTTPSValidation().spec(req)
				.body(CreateUser.userDetais());
	   
	}

	@When("user will hit the specific {string}")
	public void user_will_hit_the_specific(String endpoint) {
		
		respec=new ResponseSpecBuilder().build();
		response=res.when().post(endpoint).then().log().all().spec(respec)
				.extract().response();
		
	    
	}

	@Then("we are going to validate the status code as specific {string}")
	public void we_are_going_to_validate_the_status_code_as_specific(String status_code) throws JsonMappingException, JsonProcessingException {
	    
		long time=response.getTime();
		
		if(time<5000)
		{
			System.out.println("It is within threshold");
		}
		else
		{
			throw new ArithmeticException();
		}
		
		String s=status_code;
		int expectedStatusCode=Integer.parseInt(s);
		
		int actualStatusCode=response.getStatusCode();
		
		Assert.assertEquals(actualStatusCode, expectedStatusCode);
		
		
		JsonPath js=new JsonPath(response.asString());
		
		
	String ActualName=	js.getString("name");
	
	String ExpectedName=CreateUser.getName();
	Assert.assertEquals(ActualName, ExpectedName);
	
		
		
	}
	
	
}
