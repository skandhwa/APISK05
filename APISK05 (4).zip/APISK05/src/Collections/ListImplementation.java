package Collections;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class ListImplementation {

	public static void main(String[] args) {
		
		List<Integer> li=new ArrayList<Integer>();
		li.add(34);
		li.add(67);
		li.add(89);
		
		System.out.println(li);
		
		for(Integer x:li)
		{
			System.out.println(x);
		}
		
		Iterator itr=li.iterator();
		
		while(itr.hasNext())
		{
			System.out.println(itr.next());
		}
		
		
		
		
		

	}

}
