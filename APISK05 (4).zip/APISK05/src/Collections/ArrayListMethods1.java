package Collections;

import java.util.ArrayList;
import java.util.List;

public class ArrayListMethods1 {

	public static void main(String[] args) {
		
		List<Integer> li=new ArrayList<Integer>();
		li.add(34);
		li.add(67);
		li.add(89);
		
		List<Integer> li2=new ArrayList<Integer>();
		li.add(134);
		li.add(617);
		li.add(189);
		
		
		li.addAll(li2);
		
		System.out.println(li);
		

	}

}
