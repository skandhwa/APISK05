package ArrayExamples;

import java.util.Arrays;

public class ReverseOFArray {

	public static void main(String[] args) {
		
		int []a= {34,78,54,66,12,99};
		
		int []b=new int[a.length];
		
		for(int i=a.length-1;i>0;i--)
		{
			b[i]=a[i];
		}
		
		for(int i=0;i<b.length;i++)
		{
			System.out.println(b[i]);
		}
		
		
		

	}

}
