package ArrayExamples;

import java.util.Arrays;

public class MyFirstProgram {

	public static void main(String[] args) {
		
		int []a= {1,2,3,4,7,0,8};
		
		int []b= {1,2,3,4,5};
		
		Arrays.sort(a);
		
	  for(int i=0;i<a.length;i++)
	  {
		  System.out.println(Arrays.toString(a));
	  }
		
		System.out.println(a);
		
		
	boolean flag=	Arrays.equals(a,b);
	
	System.out.println(flag);
		
		
		

	}

}
