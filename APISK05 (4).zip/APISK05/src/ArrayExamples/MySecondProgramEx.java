package ArrayExamples;

import java.util.Arrays;

public class MySecondProgramEx {

	public static void main(String[] args) {
		
		int []a= {5,8,2,4,9,1};
		int temp;
		
		for(int i=0;i<a.length;i++)///i=0,0<6
		{
			for(int j=i+1;j<a.length;j++)//j=1,1<6//j=2,2<6
			{
				if(a[i]>a[j])///a[0]>a[1]///a[0]>a[2]
				{
					temp=a[i];
					a[i]=a[j];
					a[j]=temp;
				}
			}
		}
		
		System.out.println(Arrays.toString(a));
		
		

	}

}
