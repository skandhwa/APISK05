package ArrayExamples;

public class SumOfAllElements {

	public static void main(String[] args) {
		
		int []a= {2,5,7,8,9,12};
		int sum=1;
		
		for(int i=0;i<a.length;i++)
		{
			sum=sum*a[i];
		}
		
		System.out.println("sum of elemnts is "+sum);
		

	}

}
