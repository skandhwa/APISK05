package ExceptionHandlingExamples;

public class FinallyExample {

	public static void main(String[] args) {
		
		try
		{
			int x=10/0;
			System.out.println(x);
		}
		
		catch(Exception e)
		{
			System.out.println("caught with "+e);
		}
		
		finally
		{
			System.out.println("Hello I will always execute");
		}
		

	}

}
