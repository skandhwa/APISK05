package ExceptionHandlingExamples;

public class HandlingException2 {

	public static void main(String[] args) {
		
		try
		{
		int []n= {3,5,7,8,11};
		
		System.out.println(n[5]);
		}
		
		catch(ArrayIndexOutOfBoundsException e)
		{
			System.out.println("caught with "+e);
		}
		
		
		int a=20,b=30;
		int c=a+b;
		System.out.println("Sum is "+c);
		

	}

}
