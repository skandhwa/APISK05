package ExceptionHandlingExamples;

import java.io.FileNotFoundException;
import java.io.FileReader;

public class ThrowsClauseEx {

	public static void main(String[] args) throws FileNotFoundException {
		
		FileReader f=new FileReader("C:\\Users\\saura\\OneDrive\\Documents\\PageObjectModel.txt");
		System.out.println("File accessible");
		System.out.println("true");
		
		int a=20,b=30;
		int c=a+b;
		System.out.println("Sum is "+c);
		
		
		
		

	}

}
