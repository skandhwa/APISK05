package StringExamples;

import java.util.Arrays;

public class StringAnagramEx {

	public static void main(String[] args) {
		
		String str1="Cafe";
		String str2="FACE";
		
		str1=str1.toLowerCase();///cafe
		str2=str2.toLowerCase();///acer
		
		if(str1.length()!=str2.length())
		{
			System.out.println("Both the Strings are not anagram");
		}
		
		else
		{
			char []s1=str1.toCharArray();
			char []s2=str2.toCharArray();
			
			Arrays.sort(s1);
			Arrays.sort(s2);
			
			if(Arrays.equals(s1,s2)==true)
			{
				System.out.println("Both the String are anagram");
			}
			
			else
			{
				System.out.println("Strings are not anagram");
			}
			
			
			
		}
		

	}

}
