package StringExamples;

public class StringIndexOfEx {

	public static void main(String[] args) {
		
		String str="India is my Country and people of our country is cheerful and my people are blessed";
	int x=	str.indexOf("my",20);
	
	System.out.println("Index of is "+x);
		
		

	}

}
