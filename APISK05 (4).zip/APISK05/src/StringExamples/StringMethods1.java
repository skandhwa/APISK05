package StringExamples;

public class StringMethods1 {

	public static void main(String[] args) {
		
		String str="HelloWorld";
	int x=	str.length();
	
	System.out.println("Length of string is "+x);
	
	
	char ch=str.charAt(4);
		System.out.println(ch);
		
		
		//Saurabh 
		
		
	str=str.substring(6);
	
	System.out.println("The substring is "+str);
	
	
	

	}

}
