package StringExamples;

public class GettingAllSubStrings {

	public static void main(String[] args) {

		String str="India";
		
		
		
		
		for(int i=0;i<str.length();i++)///i=0,0<5
		{
			for(int j=i+1;j<=str.length();j++)//j=1,1<5//j=2,2<5
			{
				System.out.println(str.substring(i, j));//0,1//0,2//0,3//0,4//0,5
			
			
				
			}
			
			
		}
		
		
		
		
		
		

	}

}
