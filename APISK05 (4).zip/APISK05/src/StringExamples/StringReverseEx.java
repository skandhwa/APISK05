package StringExamples;

public class StringReverseEx {

	public static void main(String[] args) {
		
		String str="Radar";
		
		str=str.toLowerCase();
		
		String str1=str;
		String revstr="";
		
		for(int i=str.length()-1;i>=0;i--)//i=4, 4>=0// i=3,3>=0
		{
			revstr=revstr+str.charAt(i);///revstr=a+
		}
		
		
		System.out.println(revstr);
		
		if(str1.equals(revstr))
		{
			System.out.println("String is palindrome");
		}
		else
		{
			System.out.println("Not palindrome");
		}
		

	}

}
