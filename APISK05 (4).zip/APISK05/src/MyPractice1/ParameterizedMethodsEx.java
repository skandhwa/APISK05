package MyPractice1;

public class ParameterizedMethodsEx {
	
	int sum(int a,int b,float g,float h)
	{
		int c=a+b;
		System.out.println(c);
		return c;
	}
	
	class M2
	{
		float diff(int a,int b,float c)
		{
			return a+b-c;
		}
	}
	
	
	

	public static void main(String[] args) {
		
		ParameterizedMethodsEx obj=new ParameterizedMethodsEx();
	//System.out.println(obj.sum(10, 50));
//		
//		obj.sum(12, 9,54,32);
//		
//		M2 obj1=new M2();
//		obj1.diff(34, 10, 5.5f);
		
		

	}

}
