package MyPractice1;

abstract class T3
{
	abstract void demo();
	
	void display()
	{
		System.out.println("Hello");
	}
	
	void test()
	{
		System.out.println("Hi");
	}
	
	abstract void message();
	
}

class T4 extends T3
{
	void demo()
	{
		System.out.println("Hi");
	}
	
	void message()
	{
		System.out.println("Hello");
	}
}



public class AbstractClassEx {

	public static void main(String[] args) {
		
		T4 obj=new T4();
		obj.demo();
		obj.message();
		

	}

}
