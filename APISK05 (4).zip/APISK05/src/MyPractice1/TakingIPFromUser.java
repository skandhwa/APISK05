package MyPractice1;

import java.util.Scanner;

class T1
{
	void display()
	{
		System.out.println("Enter first number");
		Scanner sc=new Scanner(System.in);
		
		int num=sc.nextInt();
		System.out.println("Enter second number");
		int num1=sc.nextInt();
		
		int sum=num1+num;
		
		System.out.println("The sum of two numbers are "+sum);
		
		
	}
	
	void test()
	{
		System.out.println("Enter a character");
		Scanner sc=new Scanner(System.in);
		
		char ch=sc.next().charAt(0);
		System.out.println(ch);
		
	}
	
	
	void display1()
	{
		System.out.println("Enter a string");
		Scanner sc=new Scanner(System.in);
		
		String str=sc.nextLine();
		
		int x=str.length();
		System.out.println("The length of String is "+x);
		
		
	}
	
	
	
}




public class TakingIPFromUser {

	public static void main(String[] args) {
		
		T1 obj=new T1();
		obj.display();
		obj.display1();
		obj.test();
		
		

	}

}
