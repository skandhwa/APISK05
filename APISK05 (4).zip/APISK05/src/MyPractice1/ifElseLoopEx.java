package MyPractice1;

public class ifElseLoopEx {

	public static void main(String[] args) {
		
		int a=100;
		int b=20;
		
		if(a>b)
		{
			System.out.println("a is maximum");
		}
		else
		{
			System.out.println("b is maximum");
		}
		

	}

}
