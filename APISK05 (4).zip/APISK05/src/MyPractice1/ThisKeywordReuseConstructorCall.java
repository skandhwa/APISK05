package MyPractice1;

class Student2
{
	String name;
	int id;
	int roll;
	float fee;
	Student2(String name,int id,int roll)
	{
		this.name=name;
		this.id=id;
		this.roll=roll;
	}
	
	Student2(String name,int id,int roll,float fee)
	{
		this(name,id,roll);
		this.fee=fee;
	}
	
	void display()
	{
		System.out.println(name+" "+id+" "+roll+" "+fee);
	}
	
	
}

public class ThisKeywordReuseConstructorCall {

	public static void main(String[] args) {
		
		Student2 obj=new Student2("Saurabh",1234,8976);
		obj.display();
		
		Student2 obj1=new Student2("Saurabh",1234,8976,8976.50f);
		obj1.display();
		

	}

}
