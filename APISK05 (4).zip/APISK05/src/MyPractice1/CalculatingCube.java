package MyPractice1;

public class CalculatingCube {
	
	static int cube(int x)
	{
		return x*x*x;
	}
	

	public static void main(String[] args) {
		
		
	System.out.println(CalculatingCube.cube(5));	

	}

}
