package MyPractice1;

public class TernaryOperator {

	public static void main(String[] args) {
		
		int a=20;
		int b=40;
		
		int max= a>b ?a:b;
		
		System.out.println(max);
		

	}

}
