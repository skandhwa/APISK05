package MyPractice1;

class M5
{
	static int sum(int x,int y)
	{
		return x+y;
	}
	
	static int sum(int a,int b,int c)
	{
		return a+b+c;
	}
	
	static float sum(int d,int e,float g)
	{
		return d+e+g;
	}
	
}
public class MethodOverloadingEx1 {

	public static void main(String[] args) {
		
		M5 obj=new M5();
	System.out.println(obj.sum(20,50));	
		
	System.out.println	(obj.sum(12,13,56));
		

	}

}
