package MyPractice1;

public class ifLoopExample {

	public static void main(String[] args) {
		
		
		int x=20;
		
		if(x>5)
		{
			if(x>10)
			{
				if(x>25)
				{
					System.out.println("Hello");
				}
			}
		}
		
		
		

	}

}
