package MyPractice1;

public class LoopingEx {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
