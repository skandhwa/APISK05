package MyPractice1;

class T
{
	int i;
	boolean flag;
	
	
	T()
	{
		System.out.println("Hii");
	}
	
	
	void display()
	{
		System.out.println(i+" "+flag);
	}
	
}



public class DefaultConstructorEx {

	public static void main(String[] args) {
		
		T obj=new T();
		obj.display();
		
		
		

	}

}
