package MyPractice1;

public class Operators2 {

	public static void main(String[] args) {
		
		int x=97;
		int y=5;
		
		int z=x%y;
		
		System.out.println(z);
		
		System.out.println(194>>4);

	}

}
